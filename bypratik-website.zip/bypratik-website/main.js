// Mobile nav toggle
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
}

// Mark active nav link
const currentPage = location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a').forEach(link => {
  if (link.getAttribute('href') === currentPage) link.classList.add('active');
});

// Contact form simulation
document.querySelectorAll('form.contact-form').forEach(form => {
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const msg = this.querySelector('.success-msg');
    if (msg) { msg.style.display = 'block'; this.reset(); }
  });
});
