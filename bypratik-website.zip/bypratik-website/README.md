# bypratik Website — GitHub Pages

A complete 9-page freelance content writing website targeting Australian clients.
Built with pure HTML, CSS and vanilla JavaScript. Zero dependencies. Zero frameworks.

## Pages Included

| File | Page |
|---|---|
| `index.html` | Homepage |
| `about.html` | About Me |
| `blogs.html` | My Blogs (with filter by category) |
| `services.html` | Services overview |
| `social-media.html` | Social Media Content Management + contact form |
| `landing-page.html` | Landing Page Optimisation + contact form |
| `memes.html` | Meme Creation + contact form |
| `seo.html` | SEO / AEO / GEO Optimisation + contact form |
| `contact.html` | Contact Us + FAQ |
| `style.css` | Shared stylesheet (Australian design system) |
| `main.js` | Shared JavaScript (nav, forms) |

## How to Upload to GitHub Pages (Step by Step)

### Step 1 — Create a GitHub account
Go to github.com → Sign up for free

### Step 2 — Create a new repository
- Click the green "New" button
- Name it: `bypratik-website` (or `yourusername.github.io` for root domain)
- Set to Public
- Click "Create repository"

### Step 3 — Upload your files
- Click "uploading an existing file"
- Drag and drop ALL files from this folder (index.html, style.css, main.js, all .html pages)
- Click "Commit changes"

### Step 4 — Enable GitHub Pages
- Go to your repo → Settings → Pages (left sidebar)
- Under "Source" select "Deploy from a branch"
- Branch: main | Folder: / (root)
- Click Save
- Wait 2–3 minutes

### Step 5 — Your site is live!
Visit: `https://yourusername.github.io/bypratik-website`

## Connect Your Custom Domain (bypratik.co.in)

1. In GitHub Pages settings → Custom domain → type `bypratik.co.in` → Save
2. Go to your domain registrar (where you bought bypratik.co.in)
3. Add these DNS records:
   - A record: `185.199.108.153`
   - A record: `185.199.109.153`
   - A record: `185.199.110.153`
   - A record: `185.199.111.153`
4. Wait 24–48 hours for DNS to propagate

## Add GA4 + Microsoft Clarity

In `<head>` of every HTML file, paste your tracking codes:

```html
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>

<!-- Microsoft Clarity -->
<script type="text/javascript">
  (function(c,l,a,r,i,t,y){
    c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
    t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
    y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
  })(window, document, "clarity", "script", "YOUR_CLARITY_ID");
</script>
```

Replace `G-XXXXXXXXXX` with your GA4 measurement ID and `YOUR_CLARITY_ID` with your Clarity project ID.

## Connect a Real Contact Form (Free)

The forms currently show a success message on submit. To receive real emails, use Formspree:

1. Go to formspree.io → Sign up free
2. Create a new form → Get your endpoint URL
3. In each HTML file, change `<form class="contact-form">` to:
   `<form class="contact-form" action="https://formspree.io/f/YOUR_ID" method="POST">`
4. Remove the JavaScript form handler from main.js (or keep both)

Free Formspree plan: 50 submissions/month — plenty to start.

## Design System Reference

| Token | Value | Usage |
|---|---|---|
| `--green` | #2D5016 | Primary colour, CTAs |
| `--sand` | #F5F2ED | Backgrounds |
| `--charcoal` | #1A1A18 | Headings |
| `--bark` | #5C5A54 | Body text |
| `--ochre` | #C8873A | Accent/tags |
| `--serif` | DM Serif Display | Headings |
| `--sans` | Plus Jakarta Sans | Body text |
